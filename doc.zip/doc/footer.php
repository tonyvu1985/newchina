<footer class="site-footer" style="clear:both">
	<img src="http://newlandtravel.com.au/hoc/images/footer.jpg" class="img-responsive" />
</footer>
</div>
</body>
