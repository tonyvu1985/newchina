<div class="featured">
	<section class="widget">
		<h4>Treatments</h4>
		<ul class="treatments">
			<li><a href="">Diet & Lifestyle</a></li>
			<li><a href="cupping.php">Cupping</a></li>
			<li><a href="moxibustion.php">Moxibustion</a></li>
			<li><a href="tuina.php">Tuina</a></li>
			<li><a href="">Health Funds</a></li>
			<li><a href="article.php">Media Articles</a></li>
		</ul>
	</section>
</div>

