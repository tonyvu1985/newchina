<footer class="site-footer">
	<div class="fairfield">
		<p>Fairfield Cline - Tuesday, Thursday & Saturday</p>
		<p>62A Smart St, Fairfield</p>
		<p>Copyright 2014 New China Acupuncture</p>
	</div>
	<div class="city">
		<p>City Clinic - Monday, Wednesday & Friday</p>
		<p>Unit 95, Level 2, 515 Kent st, Sydney<br/>2 mins walk from Townhall</p>
	</div>
</footer>
